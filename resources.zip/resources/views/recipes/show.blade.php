@extends('layout')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-3 gap-8">
    
    <div class="md:col-span-2">
        <div class="bg-white rounded-3xl overflow-hidden shadow-sm mb-6">
            <img src="{{ $recipe->image }}" class="w-full h-96 object-cover">
            <div class="p-8">
                <h1 class="text-3xl font-bold text-dark mb-4">{{ $recipe->title }}</h1>
                <p class="text-lg text-stone-600 mb-6">{{ $recipe->description }}</p>
                
                <h3 class="text-xl font-bold text-dark mb-3">🧑‍🍳 Как готовить:</h3>
                <div class="prose text-stone-700 leading-relaxed whitespace-pre-line">
                    {{ $recipe->instructions }}
                </div>
            </div>
        </div>

        <div class="bg-white rounded-3xl p-8 shadow-sm">
            <h3 class="text-2xl font-bold mb-6">Отзывы ({{ $recipe->reviews->count() }})</h3>
            
            @auth
                <form action="{{ route('reviews.store', $recipe) }}" method="POST" class="mb-8 bg-secondary p-4 rounded-2xl">
                    @csrf
                    <label class="block font-bold mb-2">Оцените блюдо:</label>
                    <select name="rating" class="mb-2 p-2 rounded-lg border">
                        <option value="5">⭐⭐⭐⭐⭐ 5 - Супер</option>
                        <option value="4">⭐⭐⭐⭐ 4 - Вкусно</option>
                        <option value="3">⭐⭐⭐ 3 - Нормально</option>
                        <option value="2">⭐⭐ 2 - Так себе</option>
                        <option value="1">⭐ 1 - Ужасно</option>
                    </select>
                    <textarea name="comment" class="w-full p-3 rounded-xl border border-stone-200 mt-2" placeholder="Напишите ваш комментарий..."></textarea>
                    <button class="mt-2 bg-primary text-white px-6 py-2 rounded-xl">Отправить отзыв</button>
                </form>
            @else
                <div class="bg-gray-100 p-4 rounded-xl text-center mb-6">
                    <a href="{{ route('login') }}" class="text-primary font-bold underline">Войдите</a>, чтобы оставить отзыв.
                </div>
            @endauth

            <div class="space-y-6">
                @foreach($recipe->reviews as $review)
                    <div class="border-b border-gray-100 pb-4">
                        <div class="flex justify-between mb-2">
                            <span class="font-bold text-dark">{{ $review->user->name }}</span>
                            <span class="text-primary">★ {{ $review->rating }}</span>
                        </div>
                        <p class="text-stone-600">{{ $review->comment }}</p>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <div>
        <div class="bg-white p-6 rounded-3xl shadow-sm sticky top-24">
            <div class="flex items-center gap-4 mb-6 border-b pb-4">
                <div class="w-12 h-12 bg-gray-200 rounded-full overflow-hidden">
                    <img src="{{ $recipe->user->avatar ?? 'https://ui-avatars.com/api/?name='.$recipe->user->name }}" alt="">
                </div>
                <div>
                    <p class="text-sm text-stone-400">Автор рецепта</p>
                    <p class="font-bold text-dark">{{ $recipe->user->name }}</p>
                </div>
            </div>

            <h3 class="text-xl font-bold mb-4">🥕 Ингредиенты</h3>
            <ul class="space-y-3">
                @foreach($recipe->ingredients as $ing)
                    <li class="flex justify-between items-center bg-secondary px-3 py-2 rounded-lg">
                        <span>{{ $ing->name }}</span>
                        <span class="font-bold text-stone-500">{{ $ing->pivot->amount }}</span>
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
</div>
@endsection
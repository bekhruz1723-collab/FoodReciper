<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // Здесь обычно пусто или общие методы
}
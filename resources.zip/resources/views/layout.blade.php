<!DOCTYPE html>
<html lang="{{ $current_locale }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodReciper</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#059669',
                        primaryHover: '#047857',
                        dark: '#1c1917',
                        surface: '#ffffff',
                        background: '#fafaf9',
                    },
                    boxShadow: { 'soft': '0 4px 20px -2px rgba(0, 0, 0, 0.05)' }
                }
            }
        }
    </script>
    <style>
        body { background-color: #fafaf9; font-family: 'Inter', system-ui, sans-serif; color: #1c1917; }
        /* Делаем инпуты явно белыми и очерченными */
        input, textarea, select { 
            background-color: #ffffff !important; 
            border: 1px solid #e7e5e4 !important; 
        }
        input:focus, textarea:focus {
            border-color: #059669 !important;
            ring: 2px solid #059669;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen">

    <nav class="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <a href="{{ route('home') }}" class="text-2xl font-bold tracking-tight text-dark flex items-center gap-2">
                <span class="text-primary text-3xl">🌿</span> FoodReciper
            </a>
            
            <div class="flex gap-6 items-center text-sm font-medium">
                <div class="flex border rounded-lg overflow-hidden">
                    <a href="{{ route('locale', 'ru') }}" class="px-3 py-1 {{ $current_locale == 'ru' ? 'bg-primary text-white' : 'bg-white hover:bg-stone-100' }}">RU</a>
                    <a href="{{ route('locale', 'en') }}" class="px-3 py-1 {{ $current_locale == 'en' ? 'bg-primary text-white' : 'bg-white hover:bg-stone-100' }}">EN</a>
                </div>

                @auth
                    <a href="{{ route('recipes.create') }}" class="text-stone-600 hover:text-primary transition">{{ $t['add_recipe'] }}</a>
                    
                    <div class="relative group">
                        <button class="flex items-center gap-2 font-bold text-dark">
                            {{ Auth::user()->username }}
                        </button>
                        <div class="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-stone-100 hidden group-hover:block p-2">
                            <a href="{{ route('profile.show', Auth::user()->username) }}" class="block px-4 py-2 hover:bg-stone-50 rounded-lg">{{ $t['my_profile'] }}</a>
                            <a href="{{ route('profile.edit') }}" class="block px-4 py-2 hover:bg-stone-50 rounded-lg">{{ $t['settings'] }}</a>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button class="w-full text-left px-4 py-2 text-red-500 hover:bg-red-50 rounded-lg">{{ $t['logout'] }}</button>
                            </form>
                        </div>
                    </div>
                @else
                    <a href="{{ route('login') }}" class="text-stone-600">{{ $t['login'] }}</a>
                    <a href="{{ route('register') }}" class="bg-dark text-white px-5 py-2.5 rounded-xl hover:bg-stone-800 transition shadow-lg">{{ $t['register'] }}</a>
                @endauth
            </div>
        </div>
    </nav>

    <main class="flex-grow w-full max-w-7xl mx-auto px-6 py-10">
        @yield('content')
    </main>

    <footer class="bg-white border-t border-stone-100 py-10 mt-auto">
        <div class="max-w-7xl mx-auto px-6 text-center text-stone-400 text-sm">
            <p>&copy; 2026 {{ $t['footer'] }}</p>
        </div>
    </footer>

</body>
</html>